myReady(function(){

    //横向导航拉长效果部分
    var navigation=document.getElementsByClassName('navigation')[0];
    // var lli=navigation.getElementsByTagName('li')
    var aa=navigation.getElementsByTagName("a");
    // var firstPage=document.getElementsByClassName('firstPage')[0];
    // var SPage=document.getElementsByClassName('SPage')[0];
    
        // firstPage.onmouseover=function(){
        //  this.innerHTML="Home";
        //  // firstPage.style.fontSize="20px";
        // }
    
    for(var i=0;i<aa.length;i++){
        aa[i].onmouseover=function(){   
            // if(firstPage){   
            //  firstPage.innerHTML="Home";
            //  firstPage.style.fontSize="20px";
            // }else{
            //  firstPage.innerHTML="首  页";
            //  firstPage.style.fontSize="16px";
            // }
            // if(SPage){   
            //  SPage.innerHTML="Home";
            //  SPage.style.fontSize="20px";
            // }
            clearInterval(this.time);
            var This=this;
            This.time=setInterval(function(){   
                This.style.width=This.offsetWidth+6+'px';
                This.style.backgroundPosition="0 -30px";
                This.style.color="#fff";

                if(This.offsetWidth>=160){
                    clearInterval(This.time);
                }
            },10)
        }
        aa[i].onmouseout=function(){
            // if(firstPage){
            //  firstPage.innerHTML="首  页";
            //  firstPage.style.fontSize="16px";
            // }
            // if(SPage){   
            //  SPage.innerHTML="第二页面";
            //  SPage.style.fontSize="16px";
            // }
            clearInterval(this.time);
            var This=this;
            This.time=setInterval(function(){
                This.style.width=This.offsetWidth-6+'px';
                This.style.backgroundPosition="0 0";
                This.style.color="#000";
                if(This.offsetWidth<=100){
                    This.offsetWidth="100px";
                    clearInterval(This.time);
                }
            },10)
        }
    }
    //goTop部分
    var goTop=document.getElementsByClassName("goTop")[0];
    var gtime=null;
    var scrollControl=true;
    window.onscroll=function(){
        if(!scrollControl){
            clearInterval(gtime);
        }
        scrollControl=false;
        var clientHeight=document.documentElement.clientHeight || document.body.clientHeight;
        var scrollTop=document.documentElement.scrollTop || document.body.scrollTop;
        if(scrollTop>=clientHeight){
            goTop.style.display="block";
        }else{
            goTop.style.display="none";
        }
    }
    goTop.onclick=function(){
        gtime=setInterval(function(){
            var scrollTop=document.documentElement.scrollTop || document.body.scrollTop;
            var speed=Math.floor(-scrollTop/6);
            document.documentElement.scrollTop=document.body.scrollTop=scrollTop+speed;
            scrollControl=true;
            if(scrollTop==0){
                clearInterval(gtime);
            }
        },30)
    }

    //形形色色的下拉菜单部分  js
    // var navA=document.getElementsByClassName('navA');
    // // var list=document.getElementsByClassName('list');
    // for(var i=0;i<navA.length;i++){ 
    //  navA[i].onmouseover=function(){
    //      // var This=this;
    //      var list=this.getElementsByClassName('list')[0];
    //      list.style.display="block";
    //      this.style.width="150px";
    //      this.style.color="yellow";
    //      this.style.backgroundColor="green";
    //  }
    //  navA[i].onmouseout=function(){
    //      var list=this.getElementsByClassName('list')[0];
    //      list.style.display="none";
    //      this.style.width="100px";
    //      this.style.color="#000";
    //      this.style.backgroundColor="#666";
    //  }
    // }

    //下拉菜单动画jQuery部分
    $(".navA").hover(function() {
     $(this).find(".list").show();//show()  hide()
     $(this).css({"width":"150px","backgroundColor":"green"});
     $(this).find(".navAa").css({"color":"yellow"}); 
    }, function() {
     $(this).find(".list").css("display","none");
     $(this).css({"width":"100px","backgroundColor":"#666"});
     $(this).find(".navAa").css({"color":"#fff"});       
    });

    // //下拉菜单动画效果
    // $(".slidemenu li").mouseenter(function(){
    //  $(this).find("ul").slideToggle(200);
    //  }
    // )
    // $(".slidemenu li").mouseleave(function(){
    //  $(this).find("ul").slideToggle(200);
    //  }
    // )

    //下拉菜单动画js部分
    
        
    

    

    // var slidemenu=document.getElementsByClassName('slidemenu')[0];
    // var lli=slidemenu.getElementsByTagName('li');
    
    // for(var i=0;i<lli.length;i++){
    //  lli[i].onmouseover=function(){
    //      var u=this.getElementsByTagName('ul')[0];
    //      if(u!=undefined){
    //          u.style.display="block";
    //      }
    //      var uHeight=u.offsetHeight; 
    //      uHeight +=1;
    //      if(uHeight<=40){
    //          u.style.height=uHeight+'px';
                
    //      }
    //  }
    // }

    //js分享按钮动画
    var sidebar=document.getElementsByClassName('sidebar')[0];  
    var timeshare=null;
    sidebar.onmouseover=function(){          
        clearInterval(timeshare);
        timeshare=setInterval(function(){
            var speed=(0-sidebar.offsetLeft)/20;
            speed=speed>0?Math.ceil(speed):Math.floor(speed);
            if(sidebar.offsetLeft=="0"){
                 clearInterval(timeshare); 
            }else{
                sidebar.style.left=sidebar.offsetLeft+speed+"px";
            }
        },10)       
    }
    sidebar.onmouseout=function(){          
        clearInterval(timeshare);
        timeshare=setInterval(function(){
            var speed=(-200-sidebar.offsetLeft)/20;
            speed=speed>0?Math.ceil(speed):Math.floor(speed);
            if(sidebar.offsetLeft=="-200"){
                 clearInterval(timeshare); 
            }else{
                sidebar.style.left=sidebar.offsetLeft+speed+"px";
            }
        },10)       
    }
    
    //多物体动画javascript
    var multi=document.getElementsByClassName('multi')[0];
    var mli=multi.getElementsByTagName('li');
    for(var i=0;i<mli.length;i++){
        mli[i].timemL=null;
        mli[i].onmouseover=function(){
            mliMove(this,400);
        }
        mli[i].onmouseout=function(){
            mliMove(this,150);
        }       
    }
    // var timemL=null;
    function mliMove(obj,l){
        clearInterval(obj.timemL);
        obj.timemL=setInterval(function(){
            var speed=(l-obj.offsetWidth)/10;
            speed=speed>0?Math.ceil(speed):Math.floor(speed);
            if(l==obj.offsetWidth){
                clearInterval(obj.timemL);
            }else{
                obj.style.width=obj.offsetWidth+speed+'px';
            }
        },30)
    }

    function func(){
        alert('hello world!');

    }
    //跨浏览器事件处理程序应用
    var moonl=document.getElementsByClassName('moonl')[0];
    var moonk=document.getElementById('moonk');
    eventUtil.addHandler(moonk,'click',function(e){
        e=eventUtil.getEvent(e);
        alert(eventUtil.getElement(e));
        eventUtil.preventDefault(e);
        eventUtil.stopPropagation(e);
    });
    // eventUtil.removeHandler(moonk,'click',func);
    eventUtil.addHandler(moonl,'click',func);

})


// myReady(function(){
//  var aa=document.getElementsByTagName('a');
    
//  for(var i=0;i<aa.length;i++){
//      aa[i].onmouseover=function(){
//          clearInterval(this.time);
//          var This=this;
//          This.time=setInterval(function(){
//              This.style.width=This.offsetWidth+6+"px";
//              This.style.color="#fff";
//              This.style.backgroundPosition="0 -30px";
//              if(This.offsetWidth>=160){
//                  clearInterval(This.time);
//              }
//          },30)
//      }
//      aa[i].onmouseout=function(){
//          clearInterval(this.time);
//          var This=this;
//          This.time=setInterval(function(){
//              This.style.color="#000";
//              This.style.backgroundPosition="0 0";
//              This.style.width=This.offsetWidth-6+"px";
//              if(This.offsetWidth <=100){
//                  This.style.width="100px";
//                  clearInterval(This.time);
//              }
//          },30)
//      }
//  }

//  var goTop=document.getElementsByClassName('goTop')[0];
//  var time=null;
//  var scrollControl=true;
//  window.onscroll=function(){
//      if(!scrollControl){
//          clearInterval(time);
//      }
//      scrollControl=false;

//      var scrollTop=document.documentElement.scrollTop || document.body.scrollTop;
//      var clientHeight=document.documentElement.clientHeight || document.body.clientHeight;
//      if(scrollTop>=clientHeight){
//          goTop.style.display="block";
//      }else{
//          goTop.style.display="none";
//      }
//  }


//  goTop.onclick=function(){
//      time=setInterval(function(){
//          var scrollTop=document.documentElement.scrollTop || document.body.scrollTop;
//          var speed=Math.floor(-scrollTop/6);
//          document.documentElement.scrollTop=document.body.scrollTop =scrollTop+speed;
//          scrollControl=true;
//          if(scrollTop==0){
//              clearInterval(time);
//          }
//      },30)
//  }

// })